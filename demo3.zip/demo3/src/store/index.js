import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)
let  deCity = '上海'
try {
    if (localStorage.city){
        deCity = localStorage.city
    }
}catch (e) {}
export default  new Vuex.Store({
    state: {
        city: deCity
    },
    mutations: {
        changeCity (state,name) {
           state.city = name
           try {
            localStorage.city = name
           }catch (e) {}
        }
    }
})