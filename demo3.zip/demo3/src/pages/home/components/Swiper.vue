<template>
   <div class="banner border-bottom">
    <el-carousel :interval="6000" type="card" :autoplay="false">
        <el-carousel-item  v-for="item in list" :key="item.id">
           <img class="banner-img" :src= "item.imgUrl"/>
        </el-carousel-item>
        <div class="swiper-pagination"  slot="pagination"></div>
    </el-carousel>
   </div>
</template>

<script>
export default{
    name:'HomeSwiper',
    props:{
        list: Array 
    }
}
</script>

<style lang='stylus' scoped>
@import '~styles/varibles.styl'
  .banner >>> .el-carousel__container
      height:1.48rem
  .banner
    width:100% 
    height:2rem
    overflow:hidden
    .banner-img
       width:100%
       height:100%
</style>