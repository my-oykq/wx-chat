<template>
 <div class="icons"> 
     <swiper :options= "swiperOption">
      <swiper-slide v-for= "(myItem,index) in pages" :key= "index">
      <div class="icon" v-for= "item in myItem" :key= "item.id">
         <div class="icon-img">
             <img :src= "item.imgUrl" class="back-img"/>
         </div>
         <div class="icon-desc">{{ item.desc }}</div>
     </div>
     </swiper-slide>
     </swiper>
   </div>
</template>

<script>
export default{
    name:'HomeIcon',
    props:{
        list: Array
    },
    data () {
        return {
            swiperOption:{},
        }
    },
    computed:{
        pages () {
              const pages = []
            this.list.forEach((value,index)=>{
                 let page = Math.floor(index / 8)
                 if (!pages[page]) {
                      pages[page] = []
                 }
                 pages[page].push(value)
            })
            return pages
        }
    }
}
</script>

<style lang='stylus' scoped>
@import '~styles/mixins.styl'
   .icons 
     width:100% 
     height:0 
     padding-bottom:50% 
     overflow:hidden
     .icon 
       width:25% 
       height:0 
       padding-bottom:25% 
       float:left
       overflwo:hidden 
       position:relative
       .icon-img 
         position:absolute 
         top:0 
         left:0 
         right:0 
         bottom:.44rem 
         padding:.2rem 
         .back-img 
           height:100%
           margin: 0 auto
           display:block
       .icon-desc 
           position:absolute 
           left:0 
           right:0 
           bottom:0
           height:.54rem 
           line-height:.54rem 
           text-align:center
           font-size:.14rem
           tolerate()
</style>