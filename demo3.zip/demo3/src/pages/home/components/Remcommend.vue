<template>
  <div>
     <div class="title">热门景点</div>
     <ul>
        <li class="item" v-for="item in list" :key="item.id">
            <img :src="item.imgUrl" class="item-img"/>
           <div class="item-info border-bottom">
              <div class="item-title">{{ item.title }}</div>
              <div class="item-desc">{{ item.desc }}</div>
              <button class="item-button">查看详情</button>
           </div>
        </li>
     </ul>
  </div>
</template>

<script>
export default{
   name:'HomeRemcommend',
   props:{
     list: Array
   },
}
</script>

<style lang="stylus" scoped>
@import '~styles/mixins.styl'
   .title
     line-height:.8rem 
     background-color:#eee 
     text-indent:.2rem 
   .item 
     display:flex 
     height:1.9rem 
     overflow:hidden 
     .item-img 
       width:1.7rem
       height:1.7rem 
       padding:.1rem 
     .item-info 
       flex: 1
       padding:.1rem
       min-width:0 
       .item-title 
         line-height:.54rem 
         font-weight:bold
         font-size:.30rem
         tolerate()
       .item-desc 
         color:#ccc 
         line-height:.4rem 
         font-size:.15rem
         tolerate()
       .item-button
           background-color:#ff9300 
           line-height:.44rem
           height:.44rem
           border-radius:.06rem
           padding:0 .1rem
           margin-top:.16rem
           font-size:.10rem
</style>