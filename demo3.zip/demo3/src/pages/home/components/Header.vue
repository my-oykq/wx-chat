<template>
 <div class="header">
    <div class="header-left">
        <div class="iconfont back-icon">&#xe624;</div>
    </div>
    <div class="header-input">
     <span class="iconfont">&#xe632;</span>
        请输入景点/游戏主题</div>
      <router-link to="/city">
      <div class="header-right">{{ this.lastCity }}
        <span class="iconfont  arrow-icon">&#xe64a;</span>
     </div>
     </router-link>
    </div>
</template>

<script>
export default{
    name:'HomeHeader',
    props:{
      lastCity: String
    }
}
</script>

<style lang='stylus' scoped>
@import '~styles/varibles.styl'
   .header
     line-height:$headerHeight
     display:flex
     background-color:$bgColor
     .header-left
       width:.64rem 
       float:left 
       .back-icon
           color:#fff
           font-size:.36rem
           text-align:center
     .header-input
       background-color:#fff
       flex:1
       border:.02rem solid #666
       height:.64rem 
       line-height:.64rem 
       margin-top:.1rem
       border-radius:.1rem 
       padding-left:.2rem 
     .header-right
       float:right
       min-width:1.04rem 
       padding:0 .1rem
       text-align:center
       color:#fff
       .arrow-icon
          font-size:.24rem 
          margin-left:-.04rem
</style>