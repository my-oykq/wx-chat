<template>
  <div>
    <home-header :lastCity = "lastCity"></home-header>
    <home-swiper :list = "swiperList"></home-swiper>
    <home-icon :list = "iconList"></home-icon>
    <home-remcommend :list = "recommendList"></home-remcommend>
  </div>
</template>

<script>
import HomeHeader from './components/Header'
import HomeSwiper from './components/Swiper'
import HomeIcon from './components/Icon'
import HomeRemcommend from './components/Remcommend'
import axios from 'axios'
import { mapState } from 'vuex'
import BMap from 'BMap'
export default{
    name:'Home',
    components:{
       HomeHeader,
       HomeSwiper,
       HomeIcon,
       HomeRemcommend
    },
    data () {
      return {
         swiperList: [],
         iconList :[],
         recommendList:[],
         lastCity:'正在定位'
      }
    },
    computed:{
       ...mapState(['city'])
    },
    methods:{
       getHomeInfo () {
         axios.get('static/mock/index.json')
         .then(this.getHomeInfoSucc)
       },
       getHomeInfoSucc (res) {
          res = res.data
          if (res.ret && res.data) {
               const data = res.data
               this.swiperList = data.swiperList
               this.iconList = data.iconList,
               this.recommendList = data.recommendList
          }
       },
       currentCity () {    //定义获取城市方法
         //  if (!localStorage.city) { //如果缓存的值等于空
              const geolocation = new BMap.Geolocation();
              geolocation.getCurrentPosition((position)=>{
                const current_city = position.address.city;  //获取城市信息
                this.lastCity = current_city
                localStorage.city = this.lastCity
              },(e)=>{
                this.lastCity = "定位失败"
              }, {provider: 'baidu'});  
         //  }else {
         //       this.lastCity =  localStorage.city
         //  }
      }
       
    },
    mounted () {
       if (this.lastCity != this.city){
           this.currentCity ()
          this.getHomeInfo()
       }  
    },
   //  activated () {
   //     if (this.lastCity !== this.city) {
   //         this.lastCity = this.city
   //         this.getHomeInfo()
   //     }
   //  }
}
</script>

<style>

</style>