<template>
  <div>
      <ul class="item-back">
          <li class="item-list" v-for="item in letters" :key= "item"
              :ref = "item"
              @touchstart="handleTouchTarte"
              @touchmove ="handleTouchMove" 
              @touchend ="handleTouchEnd"
              @click="handleCityClick"
          >{{ item }}</li>
      </ul>
  </div>
</template>

<script>
export default{
    name:'CityAlphabet',
    data () {
        return{
           mytarte:false,
           startY:0,
           stop:null
        }
    },
    props:{
        cities:Object
    },
     computed:{
           letters () {
               const letter = []
               for (let i in this.cities) {
                     letter.push(i)
               }
               return letter
           }
     },
     updated () {
         this.startY = this.$refs['A'][0].offsetTop
     },
      methods:{
        handleCityClick (e) {
           this.$emit('change',e.target.innerText)
        },
        handleTouchTarte () {  
           this.mytarte = true   
        },
        handleTouchMove (e) {
            if (this.mytarte) {
                 if (this.stop) {
                    clearInterval(this.stop)
                 }
                 this.stop = setTimeout(()=>{
                    const touchY = e.touches[0].pageY - 79
                     const index =Math.floor((touchY - this.startY ) / 20)
                     if (index >= 0 && index < this.letters.length){
                          this.$emit('change',this.letters[index])
                     }
                 },16)
            }
        },
        handleTouchEnd () {
            this.mytarte = false
        }
    }
}
</script>

<style lang='stylus' scoped>
@import '~styles/varibles.styl'
   .item-back
     position:absolute 
     top:1.58rem 
     right:0 
     bottom:0 
     width:.4rem
     display:flex 
     justify-content:center
     flex-direction:column
     z-index:99
     .item-list
       line-height:.4rem
       text-align:center
       color:$bgColor
</style>