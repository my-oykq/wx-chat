<template>
 <div>
   <div class="search border-top">
       <input type="text" placeholder="请输入城市或拼音" 
           class="search-input" v-model= "wrapper"
            @focus= "handleFocus"
            @blur = "handleBlur"
            @keyup = "handleKeyUp"
       />
   </div>
   <div class="item-content" v-show= "myshow"></div>
   <div class="item" v-show="wrapper" ref="scrollList">
     <ul>
       <li class="item-list border-bottom" v-for= "item in list" :key= "item.id"
           @click = "handleCityClick(item.name)"
       >
         {{ item.name }}
       </li>
       <li class="item-list border-bottom" v-show="listLen">未找到相关城市</li>
     </ul>
  </div>
 </div>
</template>

<script>
import Bscroll from 'better-scroll'
export default{
    name:'CityList',
    props:{
      cities:Object,
    },
    data () {
       return{
          wrapper:'',
          list:[],
          myshow: false
       }
    },
    computed:{
         listLen () {
            return !this.list.length
         }
    },
    watch:{
      wrapper () {
               const letter = []
          for (let i in this.cities) {
                 this.cities[i].forEach((value)=>{
                   if(value.spell.indexOf(this.wrapper) > -1 ||
                    value.name.indexOf(this.wrapper) > -1) {
                       letter.push(value)
                 }  
              })
           }
             this.list = letter
      }
    },
    methods:{
       handleFocus () {
            if (this.wrapper == '') {
                this.myshow = true
            }
       },
       handleBlur () {
           if (this.wrapper == '') {
               this.myshow = false
           }
       },
       handleKeyUp () {
           if (this.wrapper !== '') {
                this.myshow = false
           }else{
             this.myshow = true 
           }
       },
       handleCityClick (name) {
           this.$store.commit('changeCity',name)
           this.$router.push('/')
       }
    },
   mounted () {
       this.scroll = new Bscroll(this.$refs.scrollList)
   }
}
</script>

<style lang='stylus' scoped>
@import '~styles/varibles.styl'
   .search 
     height:.72rem 
     background-color:$bgColor
     text-align:center
     padding:0 .1rem
     z-index:100
     .search-input
        width:100%
        line-height:.62rem
        height:.62rem 
        border-radius:.06rem
        text-indent:.2rem
        padding:0 .1rem
        text-align:center
        color:#666
        box-sizing:border-box
    .item-content
      height:100%
      position:absolute 
      top:1.58rem 
      left:0 
      right:0 
      background-color:#000
      z-index:100
      opacity:0.5
    .item
      height:100%
      position:fixed
      top:1.58rem 
      left:0 
      right:0
      background-color:#fff
      z-index:1
      .item-list 
        padding:.1rem
        line-height:.54rem 
        color:#666
        font-size:.12rem
</style>