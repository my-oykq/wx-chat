<template>
   <div class="option" ref = "wrapper">
    <div>
       <div class="eare">
           <div class="search-eare border-bottom">最新城市</div>
           <div class="eare-content">
               <div class="eare-list">
                   <div class="button">{{ this.$store.state.city}}</div>
               </div>
           </div>
       </div>
       <div class="eare">
           <div class="search-eare border-bottom">热门城市</div>
           <div class="eare-content">
               <div class="eare-list" v-for = "lastlist in hotcities" :key="lastlist.id"
                @click = "handleCityClick(lastlist.name)"
               >
                   <div class="button">{{ lastlist.name }}</div>
               </div>
           </div>
       </div>
       <div class="eare" v-for = "(item,key) in cities" :key = "key" :ref="key">
           <div class="search-eare border-bottom">{{ key }}</div>
           <div class="eare-item" v-for="innerItem in item" :key="innerItem.id"
                 @click="handleCityClick(innerItem.name)"
            >
               <div class="item border-bottom">{{ innerItem.name}}</div>
           </div>
       </div>
    </div>
   </div>
</template>

<script>
import Bscroll from 'better-scroll'
export default{
    name:'CityOption',
    props:{
        cities: Object,
        hotcities: Array,
        myletter: String
    },
    mounted () {
        this.scroll = new Bscroll(this.$refs.wrapper)
    },
    watch:{
      myletter () {
           if (this.myletter){
              const element = this.$refs[this.myletter][0]
            this.scroll.scrollToElement(element)
           }
      }
    },
    methods:{
        handleCityClick (name) {
           this.$store.commit('changeCity', name)
           this.$router.push('/')
        }
    }
}
</script>

<style lang='stylus' scoped>
    .option
      position:absolute 
      top:1.58rem 
      left:0 
      right:0
      bottom:0
      overflow:hidden
    .search-eare
       line-height:.54rem 
       background-color:#eee
       padding-left:.1rem
       font-size:.26rem
     .eare-content 
         padding:.1rem .6rem .1rem .1rem 
         overflow:hidden
         .eare-list 
           width:33.33%
           float:left
           overflow:hidden
           .button
             padding:.1rem 0
             margin:.1rem
             border:.02rem solid #ccc
             text-align:center
             border-radius:.06rem
    .eare-item 
      width:100% 
      .item
       line-height:.76rem 
       padding-left:.2rem 
</style>
