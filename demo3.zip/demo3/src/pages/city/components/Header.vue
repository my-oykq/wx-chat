<template>
  <div class="header">
      城市选择
      <router-link to='/'>
      <div class="iconfont header-back">&#xe624;</div>
      </router-link>
  </div>
</template>

<script>
export default{
    name:'CityHeader'
}
</script>

<style lang='stylus' scoped>
@import '~styles/varibles.styl'
  .header
    position:relative
    line-height:$headerHeight
    height:$headerHeight
    background-color:$bgColor
    text-align:center
    color:#fff
    overflwo:hidden
    font-size:.32rem
    z-index:2
    .header-back 
      color:#fff 
      width:.64rem 
      position:absolute
      top:0 
      left:0
      text-align:center
      font-size:.36rem
</style>