<template>
  <div>
      <city-header></city-header>
      <city-list :cities= "cities"></city-list>
      <city-option :cities = "cities" :hotcities = "hotcities" :myletter="myletter"></city-option>
      <city-alphabet :cities = "cities" @change="handleChangeClick"></city-alphabet>
  </div>
</template>

<script>
import CityHeader from './components/Header'
import CityList from './components/List'
import CityOption from './components/Option'
import CityAlphabet from './components/Alphabet'
import axios from 'axios'
export default{
    name:'City',
    components:{
       CityHeader,
       CityList,
       CityOption,
       CityAlphabet
    },
  data () {
      return{
          cities:{},
          hotcities:[],
          myletter:''
      }
  },
  methods:{
     getCityInfo () {
         axios.get('static/mock/city.json')
         .then(this.getCityInfoSucc)
     },
     getCityInfoSucc (res) {
          res = res.data
         if (res.ret && res.data) {
              const data = res.data
             this.cities = data.cities
             this.hotcities = data.hotCities
         }
     },
     handleChangeClick (e) {
         
         this.myletter = e  // e 是 A B C字母
     }
  },
  mounted () {
      this.getCityInfo()
  }
}
</script>

<style lang='stylus' scoped>
   .menu 
     height:50rem 
</style>